# Ember-cli

**Maintainer:** [BilalBudhani](http://www.github.com/BilalBudhani)

Ember-cli (http://www.ember-cli.com/)

### List of Aliases

alias es='ember serve'
alias ea='ember addon'
alias eb='ember build'
alias ed='ember destroy'
alias eg='ember generate'
alias eh='ember help'
alias ein='ember init'
alias eia='ember install:addon'
alias eib='ember install:bower'
alias ein='ember install:npm'
alias ei='ember install'
alias et='ember test'
alias eu='ember update'
alias ev='ember version'
